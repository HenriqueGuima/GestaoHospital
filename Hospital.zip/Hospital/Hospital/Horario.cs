﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    class Horario : Staff
    {
        //Fazer cenas com o DateTime
    }
}
